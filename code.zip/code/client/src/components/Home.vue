<template>
    <div id="app-home">
      <p>Need to Login</p>
    </div>
</template>

<script>

export default {

  data() {
    return {

    }
  },
  methods: {

  }
}
</script>

<style>

</style>
