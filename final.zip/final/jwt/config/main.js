module.exports = {
    'secret': 'secret',
    'database': 'mongodb://localhost/sugar-boiz'
}
